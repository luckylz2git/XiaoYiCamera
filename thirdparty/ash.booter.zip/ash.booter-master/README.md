# ash.booter
Autoexec.ash script changer for Xiaomi Yi camera

# Installation
*. Put Booter files on root of SD card
*. Put your favorite scripts in SCRIPTS/booter.d directory
Filename should be in format <NUMBER1-9>_<DESCRIPTION>.ash
*. Restart camera

# Usage
*. Press and hold Shutter button. Start camera.
*. When read lights starts to blink by press power button select script to load. Ex: For load 2_timelapse.ash script press button 2 times.

