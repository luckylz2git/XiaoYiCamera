# Xiaomi Yi Configurator
# http://www.tawbaware.com
# (c) Tawbaware software, 2015
#
# Description: This script runs inside the Xiaomi Yi camera and allows the user
# to enable RAW file creation, and change photographic options such as
# exposure, ISO, whitebalance, etc.  In addition, a photographic time-lapse
# feature is also available.
#
# Usage:
# 1. Install script at top level of SD card and ensure execute permissions: chmod 755 /tmp/fuse_d/xyc.sh
# 2. Enable wifi, and connect to camera using telnet (IP=192.168.42.1, user id="root", no password)
# 3. Run script: /tmp/fuse_d/xyc.sh
#
# Disclaimer: This software is not created or endorsed by Xiaomi; it relies on
# undocumented features of the Xiaomi Yi. Using this software may void your
# camera's warranty and possibly damage your camera.  Use at your own risk!
#

AASH=/tmp/fuse_d/autoexec.ash
THIS_SCRIPT=$(cd `dirname "$0"` && pwd)/`basename "$0"`
#Time-lapse params:
TLNUM=10
TLONCE="n"
TLOFF="y"
TLDELAY=12
NOUI=0
unset EXITACTION

#Todo: t ia2 -adj ev

welcome ()
{
  clear
  echo ""
  echo "   **************************** "
  echo "   *  Xiaomi Yi Configurator  * "
  echo "   *  8/11/2015    Ver 0.1.1  * "
  echo "   **************************** "
  echo ""
}


showMainMenu ()
{
  REPLY=-1
  while [ $REPLY -eq -1 ]
  do
    echo "Main Menu:"
    echo " [1] View custom photo settings"
    echo " [2] Edit custom photo settings"
    echo " [3] Reset/Delete custom photo settings"
    echo " [4] Create/Run time-lapse script"
    echo " [5] Show SD card space usage"
    echo " [6] Restart camera"
    echo " [7] Exit"

    read -p "Select option: " REPLY
    case $REPLY in
      0|1|2|3|4|5|6|7) ;;
      *) clear; echo "invalid choice"; REPLY=-1;;
    esac
  done

  clear
  return $REPLY
}

invokeProcedure ()
{
  case $1 in
    0) clear; cat $AASH;;
    1) clear; showExistingSettings;;
    2) clear; showExistingSettings; echo ""; getSettingsInput; writeAutoexec $AASH "settings";;
    3) clear; removeAutoexec; resetCameraSettings; showExistingSettings;;
    4) clear; getTLScriptInput; writeAutoexec $AASH "timelapse"; promptToRestart;;
    5) clear; showSpaceUsage;;
    6) EXITACTION="reboot";;
    7) EXITACTION="nothing";;
  esac
}

menu ()
{
  CHOICE=0
  while [[ -z $EXITACTION ]]
  do
    showMainMenu; CHOICE=$?
    invokeProcedure $CHOICE
  done
}


showSpaceUsage ()
{
    JPEG_COUNT=`find /tmp/fuse_d -name *.jpg | wc -l`
    RAW_COUNT=`find /tmp/fuse_d -name *.RAW | wc -l`
    MP4_COUNT=`find /tmp/fuse_d -name *.mp4 | wc -l`

	SPACE_TOTAL=`df -h /tmp/fuse_d | awk -F " " '/tmp/ {print $2}'`
	SPACE_USED=`df -h /tmp/fuse_d | awk -F " " '/tmp/ {print $3}'`
	SPACE_FREE=`df -h /tmp/fuse_d | awk -F " " '/tmp/ {print $4}'`
	USED_PCT=`df -h /tmp/fuse_d | awk -F " " '/tmp/ {print $5}'`

	SPACE_FREE_KB=`df -k /tmp/fuse_d | awk -F " " '/tmp/ {print $4}'`

	JPEG_LEFT=`expr $SPACE_FREE_KB / 5500`
	RAW_LEFT=`expr $SPACE_FREE_KB / 31000`
	MP4_LEFT=`expr $SPACE_FREE_KB / 88000`

	echo "SD Card space:"
	echo "  Total=$SPACE_TOTAL, Used=$SPACE_USED ($USED_PCT), Free=$SPACE_FREE"
	echo ""
	echo "File counts:"
	echo "  JPEG=$JPEG_COUNT, RAW=$RAW_COUNT, MP4=$MP4_COUNT"
	echo ""
	echo "Estimated remaining file capacity:"
	echo "  JPEG=$JPEG_LEFT, RAW=$RAW_LEFT, MP4=$MP4_LEFT minutes"
	echo ""
}


parseCommandLine ()
{
  while [ $# -gt 0 ]
  do
    key="$1"
    case $key in
      -i) ISO=$2; shift;;
      -e) EXP=$2; shift;;
      -w) AWB=$2; shift;;
      -n) RNR=$2; shift;;
      -r) RAW=$2; shift;;
      -q) NOUI=1;;
       *) echo "Warning...unknown option: $key"; shift;;
    esac
    shift # past argument or value
  done
}

parseExistingAutoexec ()
{
  #Parse existing values from autoexec.ash
  ISO=`grep "t ia2 -ae exp" $AASH 2>/dev/null | cut -d " " -f 5`
  EXP=`grep "t ia2 -ae exp" $AASH 2>/dev/null | cut -d " " -f 6`
  AWB=`grep "t ia2 -awb" $AASH 2>/dev/null | cut -d " " -f 4`
  RNR=`grep "t ia2 -adj tidx -1 -1 -1" $AASH 2>/dev/null`
  RAW=`grep "t app test debug_dump 14" $AASH 2>/dev/null`

  grep -q "#TimeLapseParams:" $AASH 2>/dev/null
  if [ $? -eq 0 ]; then
    TLNUM=`grep "#TimeLapseParams:" $AASH | cut -d " " -f 2`
    TLONCE=`grep "#TimeLapseParams:" $AASH | cut -d " " -f 3`
    TLOFF=`grep "#TimeLapseParams:" $AASH | cut -d " " -f 4`
    TLDELAY=`grep "#TimeLapseParams:" $AASH | cut -d " " -f 5`
  fi
}


resetCameraSettings ()
{
  unset ISO EXP AWB RAW RNR
  setMissingValues
}

setMissingValues ()
{
  #Set reasonable defaults for any missing values
  if [ -z "$ISO" ]; then ISO=0; fi
  if [ -z "$EXP" ]; then EXP=0; fi
  if [ -z "$AWB" ]; then AWB="y"; elif [ $AWB == "on" ]; then AWB="y"; else AWB="n"; fi
  if [ -z "$RNR" ]; then RNR="n"; else RNR="y"; fi
  if [ -z "$RAW" ]; then RAW="n"; else RAW="y"; fi
}


showExistingSettings()
{
  echo "Current custom photo settings:"
  if [ $ISO -eq 0 ]; then echo "ISO: Auto (0)"; else echo "ISO: $ISO"; fi
  if [ $EXP -eq 0 ]; then echo "Exp: Auto (0)"; else echo "Exp: $EXP"; fi
  if [ $EXP == "y" ]; then echo "AWB: On"; else echo "AWB: off"; fi
  if [ $RNR == "y" ]; then echo "Reduce NR: Yes"; else echo "Reduce NR: no"; fi
  if [ $RAW == "y" ]; then echo "RAW: Yes"; else echo "RAW: no"; fi
  echo "TLParams: $TLNUM $TLONCE $TLOFF $TLDELAY"
  echo ""
}



showExposureValues ()
{
  #TODO: Make these choices more intuitive to photographers
  printf "Enter 0-2047 to select exposure:\n"
  printf "%s\t%s\t%s\n" "0=auto-exp " "1=8s       " "8=7.7s"
  printf "%s\t%s\t%s\n" "50=6.1s    " "84=5.s     " "100=4.6s"
  printf "%s\t%s\t%s\n" "200=2.7s   " "400=1s     " "500=1s"
  printf "%s\t%s\t%s\n" "590=1/3    " "600=1/5    " "700=1/5"
  printf "%s\t%s\t%s\n" "800=1/10   " "900=1/15   " "1000=1/30"
  printf "%s\t%s\t%s\n" "1100=1/50  " "1145=1/60  " "1200=1/80"
  printf "%s\t%s\t%s\n" "1275=1/125 " "1300=1/140 " "1405=1/250"
  printf "%s\t%s\t%s\n" "1450=1/320 " "1500=1/420 " "1531=1/500"
  printf "%s\t%s\t%s\n" "1600=1/624 " "1607=1/752 " "1660=1/1002"
  printf "%s\t%s\t%s\n" "1700=1/1244" "1750=1/1630" "1800=1/2138"
  printf "%s\t%s\t%s\n" "1825=1/2448" "1850=1/2803" "1900=1/3675"
  printf "%s\t%s\t%s\n" "2000=1/6316" "2047=1/8147"
}

getDelaySuggestion ()
{
  #Delay should be sum of file write time (WT) and exposure time (ET)
  #if delay is too short, then the camera doesn't write the RAW file...
  #make delay longer as necessary, depending on shutter speed and SD card
  #performance
  WT=12
  ET=0
  if [ -n $EXP ]; then
    if [ $EXP -eq 0 ]; then ET=1;
    elif [ $EXP -lt 30 ]; then ET=8;
    elif [ $EXP -lt 50 ]; then ET=7;
    elif [ $EXP -lt 90 ]; then ET=6;
    elif [ $EXP -lt 150 ]; then ET=5;
    elif [ $EXP -lt 200 ]; then ET=4;
    elif [ $EXP -lt 300 ]; then ET=3;
    elif [ $EXP -lt 400 ]; then ET=2;
    elif [ $EXP -lt 1000 ]; then ET=1;
    else ET=0;
    fi
  fi

  return `expr $WT + $ET`
}

getExposureInput ()
{
  read -p "Exposure: ?(help), 0-2047 [Enter=$EXP]: " REPLY
  if [ -n "$REPLY" ]; then
    if [ "$REPLY" == "s" ]; then
      SKIP=1
    elif [ "$REPLY" == "?" ]; then
      showExposureValues
      getExposureInput
    elif [[ $REPLY -gt -1 && $REPLY -lt 2048 ]]; then
      EXP=$REPLY
    fi
  fi
}

getISOInput ()
{
  read -p "ISO: 0(auto), 100-25600 [Enter=$ISO]: " REPLY
  if [ -n "$REPLY" ]; then
    if [ "$REPLY" == "s" ]; then
      SKIP=1
    elif [[ $REPLY -eq 0 || $REPLY -eq 100 || $REPLY -eq 200 ||  $REPLY -eq 400 || $REPLY -eq 800 || $REPLY -eq 1600 || $REPLY -eq 3200 || $REPLY -eq 6400 || $REPLY -eq 12800 || $REPLY -eq 25600 ]]; then
      ISO=$REPLY
    else
      echo "Choose: 0,100,200,400...25600"
      getISOInput
    fi
  fi
}

getAWBInput ()
{
  read -p "Auto-Whitebalance (y/n) [Enter=$AWB]: " REPLY
  if [ "$REPLY" == "s" ]; then
    SKIP=1
  elif [ -n "$REPLY" ]; then
    AWB=$REPLY
  fi
}

getNRInput ()
{
  read -p "Reduce noise-reduction (y/n) [Enter=$RNR]: " REPLY
  if [ "$REPLY" == "s" ]; then
    SKIP=1
  elif [ -n "$REPLY" ]; then
    RNR=$REPLY
  fi
}

getRawInput ()
{
 read -p "Create RAW files (y/n) [Enter=$RAW]: " REPLY
  if [ "$REPLY" == "s" ]; then
    SKIP=1
  elif [ -n "$REPLY" ]; then
    RAW=$REPLY
  fi
}

getTLNumShots()
{
  read -p "Enter number of shots (1-9999) [Enter=$TLNUM]: " REPLY
  if [ -n "$REPLY" ]; then TLNUM=$REPLY; fi
}

getTLOnce()
{
  read -p "Run once only? (y=once/n=multi) [Enter=$TLONCE]: " REPLY
  if [ -n "$REPLY" ]; then TLONCE=$REPLY; fi
}

getTLOff()
{
  read -p "Poweroff when complete (y/n) [Enter=$TLOFF]: " REPLY
  if [ -n "$REPLY" ]; then TLOFF=$REPLY; fi
}

getTLDelay()
{
  getDelaySuggestion
  TLDELAY=$?
  read -p "Delay between shutter press (secs) [Enter=$TLDELAY]: " REPLY
  if [ -n "$REPLY" ]; then TLDELAY=$REPLY; fi
}


getTLScriptInput ()
{
  getTLNumShots
  getTLOnce
  getTLOff
  getTLDelay
}


getSettingsInput ()
{

  SKIP=0
  getExposureInput
  if [ $SKIP -eq 1 ]; then return; fi

  getISOInput
  if [ $SKIP -eq 1 ]; then return; fi

  getAWBInput
  if [ $SKIP -eq 1 ]; then return; fi

  getNRInput
  if [ $SKIP -eq 1 ]; then return; fi

  getRawInput
  if [ $SKIP -eq 1 ]; then return; fi
}


removeAutoexec ()
{
  #Note: This works in "t": rm 'd:\autoexec.ash'
  rm -f /tmp/fuse_d/autoexec.ash
}

writeAutoexec ()
{
  OUTFILE=${1:-$AASH}
  SCRIPT_TYPE=${2:-"settings"}

  echo "Writing $OUTFILE"

  #Write any necessary script commands to autoexec.ash
  echo "#Script created `date`" > $OUTFILE
  echo "#CameraParams: $ISO $EXP $AWB $RNR $RAW" >> $OUTFILE
  echo "#TimeLapseParams: $TLNUM $TLONCE $TLOFF $TLDELAY" >> $OUTFILE
  echo "" >> $OUTFILE

  if [[ $ISO -ne 0 || $EXP -ne 0 ]]; then
    echo "#Set ISO and exposure" >> $OUTFILE
    echo "t ia2 -ae exp $ISO $EXP" >> $OUTFILE
    echo "" >> $OUTFILE
  fi

  if [ $AWB == "n" ]; then
    echo "#Set auto-whitebalance" >> $OUTFILE
    echo "t ia2 -awb off" >> $OUTFILE
    echo "" >> $OUTFILE
  fi

  if [ $RNR == "y" ]; then
    echo "#Reduce noise reduction as much as possible" >> $OUTFILE
    echo "t ia2 -adj tidx -1 -1 -1" >> $OUTFILE
    echo "" >> $OUTFILE
  fi


  if [ $RAW == "y" ]; then
    echo "#Create RAW files" >> $OUTFILE
    echo "t app test debug_dump 14" >> $OUTFILE
    echo "" >> $OUTFILE
  fi

  echo "" >> $OUTFILE

  #If requested, write time-lapse script
  if [ $SCRIPT_TYPE == "timelapse" ]; then
    echo "#Timelapse Script:" >> $OUTFILE
    #Pause to allow camera to boot up before starting
    echo "sleep 10" >> $OUTFILE

    CTR=0
    while [ $CTR -lt $TLNUM ];  do
      echo "t app key shutter" >> $OUTFILE
      echo "sleep $TLDELAY" >> $OUTFILE
      CTR=`expr $CTR + 1`
    done
    echo "" >> $OUTFILE

    if [ $TLONCE == "y" ]; then
      #rewrite a new autoexec.ash with current photo params
      echo "lu_util exec '$THIS_SCRIPT -i $ISO -e $EXP -w $AWB -n $RNR -r $RAW -q'" >> $OUTFILE
      echo "" >> $OUTFILE
    fi

    if [ $TLOFF == "y" ]; then
      echo "poweroff yes" >> $OUTFILE
      echo "" >> $OUTFILE
    fi
  fi
}


promptToRestart ()
{
  REPLY="n"
  read -p "Restart camera now (y/n)? [Enter=$REPLY]: " REPLY
  if [ -n $REPLY ]; then
    if [ $REPLY == "y" ]; then EXITACTION="reboot"; fi
  fi
}


#Main program
parseExistingAutoexec
parseCommandLine $*
setMissingValues

if [ $NOUI -eq 1 ]; then
  writeAutoexec
else
  welcome
  menu
fi

if [ "$EXITACTION" == "reboot" ]; then
  echo "Rebooting now..."
  sleep 1
  reboot yes
elif [ "$EXITACTION" == "poweroff" ]; then
  echo "Shutting down now..."
  sleep 1
  poweroff yes
fi
