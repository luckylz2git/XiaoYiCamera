YiMode-FI | Full Injection the Easy way to switch mode XiaoYi Cam Script
YiMode-FI Version 1.0
Compiled and Finishing By: Moch. Luthfi Rahmadi
Special Thanks To: Luckylz, Nutsey, and Andy_S

Original Source: https://forum.dashcamtalk.com/threads/button-combination-mode-switching-via-ash-scripts.12846/

CAUTION! USE SCRIPTS AT YOUR OWN RISK! THE SCRIPTS ARE PROVIDED "AS IS". ANY MODIFICATIONS OF THESE SCRIPTS CAN RESULT IN DATA LOSS AND DAMAGE YOUR CAMERA!

[How to install]
Just download the zip file and unzip to the root of SD Card, rename the [install.ash] to [autoexec.ash], then power on Yi Cam with this SD Card inserted. If Yi Cam boots with a 2-seconds long beep, means install successfully.

[How to uninstall]
Rename the [uninstall.ash] to [autoexec.ash], then power on Yi Cam with this SD Card inserted. . If Yi Cam boots with a 2-seconds long beep, means uninstall successfully.

[Mode Status]
[Mode 0: Default] - Yi Cam normally power on without special beep, enter to this mode;
[Mode 1: YiMax Image Optimization] - Yi Cam normally power on with 2 times 2-second long beep, enter to this mode.
[Mode 2: Long Exposure] - Yi Cam normally power on with 3 times 2-second long beep, enter to this mode.

[How to Use]
[Mode 0]
---> with wifi on
---> turn off wifi
---> auto reboot
---> change to [Mode 1: YiMax Image Optimization]
[Mode 1]
---> with wifi on
---> turn off wifi
---> auto reboot
---> change to [Mode 2: Long Exposure ISO 200/7,9s]
[Mode 2]
---> with wifi on
---> turn off wifi
---> auto reboot
---> change to [Mode 0: Default]
[Mode 0]
...
and so on
...