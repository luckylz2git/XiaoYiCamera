YiMode-FI | Full Injeksi Cara Mudah Untuk Merubah Script XiaoYi Cam
YiMode-FI Version 1.0
Dikompilasi dan Diselesaikan Oleh: Moch. Luthfi Rahmadi
Terimakasih Kepada: Luckylz, Nutsey, and Andy_S

Sumber Original: https://forum.dashcamtalk.com/threads/button-combination-mode-switching-via-ash-scripts.12846/

PERINGATAN! MENGGUNAKAN SCRIPT ATAS RISIKO ANDA SENDIRI! SCRIPT DISEDIAKAN "SEBAGAIMANA ADANYA". SETIAP MODIFIKASI INI SCRIPT DAPAT MENYEBABKAN KERUGIAN DATA DAN MERUSAK KAMERA!

[Cara Install]
Download file zip dan unzip pada root SD Card, rename [install.ash] menjadi [autoexec.ash], kemudian nyalakan Yi Cam dengan SD Card didalamnya. Jika Yi Cam hidup dengan 2 detik beep panjang, ini mengartikan instalasi berhasil.

[Cara uninstall]
Rename [uninstall.ash] menjadi [autoexec.ash], kemudian nyalakan Yi Cam dengan SD Card didalamnya. Jika Yi Cam hidup dengan 2 detik beep panjang, ini mengartikan pencopotan instalasi berhasil.


[Mode Status]
[Mode 0: Default] - Yi Cam menyala secara normal tanpa beep spesial, artinya masuk mode ini;
[Mode 1: YiMax Image Optimization] - Yi Cam menyala secara normal dengan 2 kali 2-detik beep panjang, artinya masuk mode ini.
[Mode 2: Long Exposure] - Yi Cam menyala secara normal dengan 3 kali 2-detik beep panjang, artinya masuk mode ini.

[Cara Menggunakan]
[Mode 0]
---> Dengan WiFi Menyala
---> Matikan WiFi
---> Otomatis Reboot
---> Berubah ke [Mode 1: YiMax Image Optimization]
[Mode 1]
---> Dengan WiFi Menyala
---> Matikan WiFi
---> Otomatis Reboot
---> Berubah ke [Mode 2: Long Exposure ISO 200/7,9s]
[Mode 2]
---> Dengan WiFi Menyala
---> Matikan WiFi
---> Otomatis Reboot
---> Berubah ke [Mode 0: Default]
[Mode 0]
...
Dan Seterusnya
...